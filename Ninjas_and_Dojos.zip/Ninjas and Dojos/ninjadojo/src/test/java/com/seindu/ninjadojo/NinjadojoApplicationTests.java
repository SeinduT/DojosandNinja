package com.seindu.ninjadojo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NinjadojoApplicationTests {

	@Test
	void contextLoads() {
	}

}
